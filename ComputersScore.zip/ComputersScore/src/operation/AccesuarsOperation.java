package operation;

import java.util.List;
import types.Accesuars;
public interface AccesuarsOperation {
    List<Accesuars> getListOfTovarA();
    List<Accesuars> addNewTovarA(Accesuars item);
    int getSumOfTovarA();
}
