package operation;

import java.util.List;
import types.ForPC;
public interface ForPCOperation {
    List<ForPC> getListOfTovarF();
    List<ForPC> addNewTovarF(ForPC item);
    int getSumOfTovarF();
}
